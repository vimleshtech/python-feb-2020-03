class cal:

    def __init__(self):
        print('object is created')

    def add(self,a,b):
        print(a+b)

    def __del__(self):
        print('object is removed, you can not use further same object')



#create an object
o = cal()
o.add(55,66)

#remove the object
del o


