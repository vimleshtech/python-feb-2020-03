class cal:
    def add(self,a,b):
        print(a+b)
        
    def sub(self,a,b):
        print(a-b)

class tax(cal): #exend teh class clas into tax

    def compute(self,amt):
        if amt<300000:
            tax =0
        elif amt<500000:
            tax = amt*.05
        elif amt<1000000:
            tax = amt*.20
        else:
            tax = amt*.30

        self.add(amt,tax)
        
        
                
o = cal()
o.add(11,4)
o.sub(55,6)

#create an object of child class, child class object can access parent class method 
x = tax()
x.add(55,3)
x.sub(55,3)
x.compute(55555)


