#multiple inheritence

class a:
    def hello(self):
        print('in a class ')



class b:
    def hi(self):
        print('in b class')

class c(a,b): #multiple, 2 parents and one child
    def welcome(s):
        print('in c method ')



#object of c
o =c()
o.hello()
o.hi()
o.welcome()
