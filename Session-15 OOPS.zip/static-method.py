#Class vs Instance Variables vs Static Variables
class example:


    
    def add(self,a,b):
        print(a+b)
        
    @staticmethod #call be called without object ref     
    def mul(a,b):
        print(a+b)

#example.mul(11,4)

#example.add(11,3)
#example.add2(11,3)

e =example()
#e.add(1,1)
e.add(44,5)
e.mul(5,3)







