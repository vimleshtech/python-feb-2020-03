class example:

    def __init__(self,name):
        self.object_name = name


    def setData(self):
        self.eid = int(input('enter eid :'))
        self.salary = int(input('enter salary :'))


    def getData(self):
        print(self.object_name)
        print(self.eid)
        print(self.salary)

    def __repr__(self): #or __str__ 
        return self.object_name

    def __add__(self,ns):
        return self.object_name+ns
    
e = example('User1')
e.setData()
e.getData()

#print object name
print(e) #show name instead of address

print(e+' hello') #error





