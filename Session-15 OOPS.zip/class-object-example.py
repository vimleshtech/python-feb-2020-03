#define the class
class Student:
    def newStudent(self): #here self is vaiable wihic take a ref of object
        #self is not a reserved name, we can take any name
        
        print('in new student')
        print(self) #print address of object

        #input from user
        self.sid = int(input('enter student id :'))
        self.sname = input('enter student name:')
        self.hs = int(input('enter mark in hindi:'))
        self.es = int(input('enter mark in eng:'))
        self.cs = int(input('enter mark in comp :'))
        self.ms = int(input('enter mark in math :'))        

    def compute(self):
        #compute total score, avg, and grade
        self.total = self.hs+self.es+self.cs+self.ms
        self.avg = self.total/4

        if self.avg>=80:
            self.grade ='A'
        elif self.avg>=60:
            self.grade ='B'
        elif self.avg>=40:
            self.grade ='C'
        else:
            self.grade ='D'            
        
    def showStudent(self):
        print('----- Student Information ----- ')        
        print('Student id  :',self.sid)
        print('Student name  :',self.sname)
        print('Student total score :',self.total)
        print('Student avg score :',self.avg)
        print('Student grade :',self.grade)        

#create an object of class
c = Student() #here c is an object of class Student
print(c) #c contains the address of object 

#call to method or function
c.newStudent()
c.compute() 
c.showStudent()

