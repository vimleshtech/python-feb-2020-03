def add(a,b):
    print(a+b)


def add(a,b,c):
    print(a+b+c)
    

add(11,44,11)
