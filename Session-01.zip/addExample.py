
a = input('enter data ')

b = input('enter data ')

print(type(a))
print(type(b))

c =int(a)+ int(b) #int() convert str to int

print(c)

