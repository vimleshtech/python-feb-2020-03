
fn = input()
ln = input('enter fname :')

name =fn+' '+ln

print('name is ',name)

