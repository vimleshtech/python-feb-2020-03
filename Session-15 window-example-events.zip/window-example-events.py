from tkinter import *
#import tkMessageBox #pip install tkMessageBox

o = Tk()
o.title('Registration page')
o.geometry("500x500") #widht * height

#####First Name
fnl=Label(text='Enter First Name :')
fnl.pack()

fn=Entry()
fn.pack()

#####Last Name
lnl=Label(text='Enter Last Name :')
lnl.pack()

ln=Entry()
ln.pack()

#####Last Name
el=Label(text='Enter Email Id :')
el.pack()

e=Entry()
e.pack()

##message
msg= Label(text='')
msg.pack()

#clear form function
def frm_clear():
    #reset form data
    fn.delete(0,'end') #reset the '' value
    ln.delete(0,'end') #reset the '' value
    e.delete(0,'end') #reset the '' value
    
#events
def clear():
    print('you have clicked on clear button ')
    frm_clear()
    
    
def save():
    print('you have clicked on save button ')
    #read data from form
    sfn= fn.get()
    sln= ln.get()
    se= e.get()
    frm_clear()
    print(f'you have entered name  {sfn} {sln} and email is {se}')
    msg.configure(text=f'you have entered name  {sfn} {sln} and email is {se}')
    #tkMessageBox.showinfo("hi")
    


bclear=Button(text='Clear',command=clear)
bclear.pack()
bsubmit=Button(text='Submit',command=save)
bsubmit.pack()

o.mainloop()
