from tkinter import *

o = Tk()
o.title('Registration page')
o.geometry("500x500") #widht * height

#####First Name
fnl=Label(text='Enter First Name :')
fnl.pack()

fn=Entry()
fn.pack()

#####Last Name
lnl=Label(text='Enter Last Name :')
lnl.pack()

ln=Entry()
ln.pack()

#####Last Name
el=Label(text='Enter Email Id :')
el.pack()

e=Entry()
e.pack()

bclear=Button(text='Clear')
bclear.pack()
bsubmit=Button(text='Submit')
bsubmit.pack()

o.mainloop()
