class cal:
    def __init__(self,a):
        self.n1 = a
    def __gt__(self,n2):
        if self.n1>n2:
            return 'greater number is '+str(self.n1)
        else:
            return 'greater number is '+str(n2)
    def __sub__(self,a):
        return self.n1-a
    

'''
__add__()
__sub__()
__mul__()

__gt__()
__ge__()
__lt__()
__le__()
__eq__()

'''

c = cal(100)
print(c>20)
print(c-40)

