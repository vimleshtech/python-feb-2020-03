
n1= [[11,22,4],
     [1,2,40],
     [110,20,10]]

n2= [[1,2,40],
     [3,5,10],
     [10,1,100]]

n =[[0,0,0],
    [0,0,0],
    [0,0,0]]


for i in range(len(n1)): #by row
    for j in range(len(n1[0])): #by col

        for k in range(len(n2)):
            n[i][j]+= n1[i][k] *n2[k][j]
        

print(n)






    
    
