s = input('enter string :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.capitalize())

print(s.swapcase())

print(s.strip())
print(s.lstrip())
print(s.rstrip())

print(len(s))
print(s.count('a'))


print(ord('A'))

print(chr(48)) # 0 to 9  : 48 to 57 

'''
for i in range(5):
    d = input('enter data :')
    print(ord(d))
'''
n = s.split(' ')
print(n)
print(n[0])
print(n[1])


l  = list(s)
print(l)



s = s.replace(' ','')
print(s)


if s.isupper():
    print('in upper case ')


if s.islower():
    print('in lower case ')


if s.isdigit():
    print('number  ')


if s.endswith('ab'):
    print('ending with ab ')
    

    


    
















