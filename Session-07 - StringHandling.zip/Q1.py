x = []

for i in range(10):
    d = int(input('enter data :'))
    x.append(d)



##find given digit
nd = int(input('enter data to search :'))

c = 0
for data  in x:
    if nd ==data:
     c =c+1

print('count of {} is {}'.format(nd,c))
