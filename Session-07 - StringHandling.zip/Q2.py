x = []

for i in range(10):
    d = int(input('enter data :'))
    x.append(d)


t = set(x)

for data in t:
    c = 0
    for d in x:
        if d == data:
            c =c+1
    print('count of {} is {}'.format(data,c))
    

