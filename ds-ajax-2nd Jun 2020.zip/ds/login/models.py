from django.db import models
import mysql.connector as con 
# Create your models here.

conn = con.connect()
cur = conn.cursor()

def validate_email(email):

    sql="select * from users where email='"+email+"'"

    cur.execute(sql)
    res = cur.fetchall()
    if len(res)>0:
        return 'Email id already exist'
    else:
        return 'NA'
        








