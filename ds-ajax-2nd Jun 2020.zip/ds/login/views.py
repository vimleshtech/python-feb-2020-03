from django.shortcuts import render
from django.http import HttpResponse 
# Create your views here.
def index(request):
    return render(request,"login/register.html")
     

def validate_email(request):
    email_list = ['raman@gmail.com','pooja@yahoo.com','nitin@gmail.com','monika101@gmail.com']

    email = request.GET['email']

    msg='NA'
    if email in email_list:
        msg = 'Email is already exist'
        

    return HttpResponse(msg)




