
from django.urls import path
from . import views 
urlpatterns = [

    path('validate_email',views.validate_email,name='validate_email') ,
    path('', views.index,name="index"),

]
