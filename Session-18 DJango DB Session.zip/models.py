# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
#install package 
#pip install mysql-connector

import mysql.connector as c
# Create your models here.

#establish the connection 
con = c.connect(host='localhost',user='root',password='root',database='django')
cur  = con.cursor()

def createUser(fname,lname):
    sql ="insert into users(fname,lname) values('"+fname+"','"+lname+"')" 

    cur.execute(sql)
    con.commit() #save data 
    print('User is created ')

def getUser():
    sql ="select * from users"
    cur.execute(sql)
    data = cur.fetchall()
    for row in data:
        print(row)


#call to function 
#createUser('Chahat','Sharma')
getUser()




