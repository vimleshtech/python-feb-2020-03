f = open(r'C:\Users\vkumar15\Desktop\SOP.txt','r') #read mode

#print(f) #print object ref
#print(f.read())

#print(f.readline())
#print(f.readline())
#print(f.readline())
#print(f.readline())

#print(f.readlines())

data =f.readlines()
f.close()

#word count
c = 0
#find the word
for r in data:
    #print(r)
    wc = r.split(' ')
    c += len(wc)
    if 'of' in wc:
        print('of is found ')
    
    
#row count
print(len(data))
print(c)


