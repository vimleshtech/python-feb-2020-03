f = open(r'C:\Users\vkumar15\Desktop\out.txt','a') #write , create file

for i in range(5):
    s = input('enter data ')
    f.write(s+'\n')


f.close()

    
print('file is saved ')



