#create class 
class emp:

    #create method or function
    def newEmployee(a): #self is variable which receive the object ref
        print('in new employee function ',a)
        a.eid = input('enter emp id :')
        a.name = input('enter emp name :')
        
    def showEmployee(s):
        print('in show employee ')
        print(f'id is {s.eid} name is {s.name}')
        #print('id is {0} name is {1}'.format(s.eid,s.name))
        


#create an object
o = emp()
print(o) #print address of object

#call to function
o.newEmployee() 
o.showEmployee()

        
    
