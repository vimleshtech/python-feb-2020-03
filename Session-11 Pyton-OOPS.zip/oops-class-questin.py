class student:

    def newStudent(self):
        self.sid = int(input('enter eid :'))
        self.sname =input('enter name:')
        self.ms = int(input('enter mark in math :'))
        self.hs = int(input('enter mark in hindi :'))
        self.es = int(input('enter mark in eng :'))
        self.cs = int(input('enter mark in comp :'))
        

    def __init__(self): #conctructor
        print('object is created ')
        self.sid=0
        self.sname=''
        self.hs =0
        self.es=0
        self.ms=0
        self.cs=0
        self.total=0
        self.avg=0
        self.grade=''
        
        
    def gradeCard(self):
        #compute
        self.total = self.ms+self.hs+self.es+self.cs
        self.avg =self.total/4
        grade =''
        if self.avg>80:
            grade ='A'
        elif self.avg>60:
            grade ='B'
        elif self.avg>60:
            grade='C'

        else:
            grade='D'

            
        self.grade = grade  


    def show(self):
        print('---student details ------')
        print(f'{s.sid} {s.sname} {s.total} {s.avg} {s.grade}')
        

#create an object
s = student()
s.newStudent()
s.gradeCard()
s.show()



        
