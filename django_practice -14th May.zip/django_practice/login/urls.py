
from django.conf.urls import url
from . import views
#.   current directory or folder
#views  is file or module name 

urlpatterns = [   
    url('home',views.home,name='home') ,
    url('about',views.about,name='about') ,
    url('',views.index,name='index') , #'' is for default landing , and this should at end 
]
