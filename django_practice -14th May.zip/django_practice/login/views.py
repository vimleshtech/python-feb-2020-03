# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def index(request):
    #return HttpResponse("<h1> This is my first application </h1><p> Name <input type='text' /> </p>")
    return render(request,'login/signup.html')
    
def home(request):
    return HttpResponse('hi, this is home page')


def about(request):
    return HttpResponse('hi, this is about me')
    



