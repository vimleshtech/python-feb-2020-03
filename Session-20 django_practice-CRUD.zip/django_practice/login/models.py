# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
#install package 
#pip install mysql-connector

import mysql.connector as c
# Create your models here.

#establish the connection 
con = c.connect(host='localhost',user='root',password='root',database='pydb')
cur  = con.cursor()

def createUser(fn,ln,email,pwd,country):
    sql ="insert into users(fname,lname,email,pwd,country) values('"+fn+"','"+ln+"','"+email+"','"+pwd+"','"+country+"')" 

    msg =''
    try:
        cur.execute(sql)
        con.commit() #save data 

        msg= 'User is created'
    except:
        msg='something went wrong'

    return msg 


def getUser():
    sql ="select * from users"
    cur.execute(sql)
    data = cur.fetchall()

    res =[]
    for row in data:
        d= {}        

        d['uid']= row[0]
        d['fname']= row[1]
        d['lname']= row[2]
        d['email']= row[3]
        d['pwd']= row[4]
        d['country']= row[5]

        res.append(d)        

    print(res)
    return res 
def delUser(uid):
    sql ="delete from users where uid="+uid
    cur.execute(sql)
    con.commit() #save data 
    return "User is removed"

    
#call to function 
#createUser('Chahat','Sharma')
#getUser()




