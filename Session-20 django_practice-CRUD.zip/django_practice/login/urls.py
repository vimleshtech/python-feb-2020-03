
from django.conf.urls import url
from . import views
#.   current directory or folder
#views  is file or module name 

urlpatterns = [   
    url('home',views.home,name='home') ,
    url('about',views.about,name='about') ,
    url('singup',views.singup,name='singup'),
    url('getdata',views.getdata,name='getdata'),
    url('deluser',views.deluser,name='deluser'),
    url('',views.index,name='index') , #'' is for default landing , and this should at end 
]
