#F15
def pow(x,n):
    return x**n
def fact(n):
    if n==1:
        return n
    else:
        return n*fact(n-1)

def equ(x,n):
    out =1
    p=2
    for i in range(n): #from 2 till <n and step by 2
        out+=pow(x,p)/fact(p)
        p+=2
    return out
