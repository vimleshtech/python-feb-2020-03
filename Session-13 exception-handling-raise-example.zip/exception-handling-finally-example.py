#Exmple: handle the arithmetic exception with finally
n = int(input('enter data :'))
x = int(input('enter data :'))

#get the division 
try:    
    o = n/x
    print('output is  ',o)
except ZeroDivisionError as err:
    print(err)
    f = open(r'C:\Users\vkumar15\Desktop\node-js\log.txt','w')
    f.write(str(err)+'\t input is {}/{}'.format(n,x)+"\n")
    f.close()
    
except NameError as er:
    print(er)
except:   #handle ther all types error   
    print('there is something wrong')
finally:
    print('division block is closed ')
    

##get the sum
o = n+x
print(o)




