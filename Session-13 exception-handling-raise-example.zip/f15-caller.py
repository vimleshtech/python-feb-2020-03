from F15 import equ
x=int(input('enter value for x :'))
n=int(input('enter number for times :'))


out= equ(x,n)
print('otuput is ',out)


    

