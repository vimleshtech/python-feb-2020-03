
f = open(r'C:\Users\vkumar15\Desktop\node-js\log.txt','w')

try:
    f.write('hi')
    #transaction 
except:
    print('there is some error')    
finally:
    f.close()
    print('file is close')

    
    
