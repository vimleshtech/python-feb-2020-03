n = int(input('enter data :'))
x = int(input('enter data :'))

try:
    if x<0:
        #create the custom error
        er = NameError('divisor cannot be less than 0')
        raise er #go to error block 
        
    o = n/x
    print(o)
except ZeroDivisionError as e:
    print(e)
except NameError as e:
    print(e)    
except:
    print('ther is some error')


    
