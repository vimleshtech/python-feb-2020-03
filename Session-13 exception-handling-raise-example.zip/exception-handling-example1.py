#Example: no exception handling
'''
n = int(input('enter data :'))
x = int(input('enter data :'))

o = n/m #will throw the error that m is not defined
print('output is  ',o)
'''

#Example : handle the exception
n = int(input('enter data :'))
x = int(input('enter data :'))
try:    
    o = n/m 
    print('output is  ',o)
except:
    #pass
    print('there is something wrong')
    

#Exmple: handle the arithmetic exception 
n = int(input('enter data :'))
x = int(input('enter data :'))
try:    
    o = n/x
    print('output is  ',o)
except ZeroDivisionError as err:
    print(err)
    f = open(r'C:\Users\vkumar15\Desktop\node-js\log.txt','w')
    f.write(str(err)+'\t input is {}/{}'.format(n,x)+"\n")
    f.close()
    
except NameError as er:
    print(er)
except:   #handle ther all types error   
    print('there is something wrong')
    














