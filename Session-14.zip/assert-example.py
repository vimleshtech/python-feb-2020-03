
#arrert example: valdiate the test data

n ="hi"

assert n =="hi"  #if match
print(n)

assert n =="hello"  #if match
print(n)
