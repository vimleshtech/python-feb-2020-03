
import re

st = input('enter string :')

#match 
#contains "are"
m = re.match('(.*) are (.*) is (.*)',st)

if m: #is match
    print('are is match ')
else:
    print('are is not match')


#validate the email id
#search
email = input('enter valid gmail id :')
m = re.search('@gmail.com$',email)
if m:
    print('valid email id ')
else:
    print('invalid email id ')


    


    
