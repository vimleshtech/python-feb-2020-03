import re

st = input('enter string :')

#match 
#contains "are"
#re.IGNORECASE 
m = re.match('(.*) are (.*) is (.*)',st,re.IGNORECASE)
#(.*) group 1 

if m:
    print(m.groups())
    print(m.group(1))
    print(m.group(2))
    print(m.group(3))
else:
    print('not match ')
