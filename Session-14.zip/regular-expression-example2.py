import re

s="Python are programing lang"

o = re.search("^Python.*language$",s)
if o:
    print('correct')
else:
    print('incorrect')
    
