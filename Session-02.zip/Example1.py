#print('hi, this is first code')
#print('test ,... bye')


print('hi, this is first code',end='-') #end=''  : replace \n with ''
print('test ,... bye')


#input
x = input() #here x is variable and input() function to read data from user
y = input('enter data :')

print('you have entered ',x)
print('you have entered ',y)



