a = input('enter data ')
b = input('enter data ')

c =a+b

print('value of a and b ')
print('value of ',a,' and ',b)

#
print('value of a is {} and b is {}'.format(a,b))
print('value of a is {0} and b is {1}'.format(a,b))
#

print('value of a is {1} and b is {0}'.format(a,b))

#
print('value of a is {0} and b is {0}'.format(a,b))

#print('value of a is {0} and b is {}'.format(a,b)) #error 

print(a,'value of a is {0} and b is {0}'.format(a,b))


