a=int(input("enter 1st int"))
b=int(input("enter 2nd int"))
c=int(input("enter 3rd int"))
d=int(input("enter 4th int"))
e=(a**3+b**3+c**3)==d**3

print(e)

if e:
    print('condition match')
else:
    print('not match')

#show greater number from three input
if a>b and a>c:
    print('a is gt')
elif b>a and b>c:
    print('b is gt')
else:
    print('c is gt')


    
    
