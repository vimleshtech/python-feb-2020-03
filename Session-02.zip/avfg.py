#wap to get name , mark in 3 subject and show total and avg

name = input('enter name :')
hs = int(input('enter mark in hindi :'))
ms = int(input('enter mark in math :'))
cs = int(input('enter mark in comp:'))



total  =hs+ms+cs
print(total)
print(total/3)


