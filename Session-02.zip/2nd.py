a=int(input("enter number"))
print(a**2)
print(a**3)
