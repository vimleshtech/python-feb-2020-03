
#i. no argument no return
def welcome():
    print('this is test function ')


#ii. no argument with return
def getNum():
    a = int(input('enter data :'))
    b = int(input('enter data :'))
    return a,b

#iii. argument with no return
def add(a,b):
    c =a+b
    print(c)
    
#iv. argument with returm
def sub(a,b):
    c =a-b
    return c

#call to function 
welcome()
welcome()


x,y =getNum()
print(x+y)


add(556,67)
add(66,777)


s = sub(55,66)
print(s)
