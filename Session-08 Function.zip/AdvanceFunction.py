
#advance function 
#v.  argument with default parameter
def add(a,b=0,c=0,d=0,e=0):
    print(a+b+c+d+e)
    
#vi. argument with dynamic count
def mul(*arg):
    print(type(arg)) #tuple
    print(arg)
    f =1
    for x in arg:
        f*= x
    print(f)
    
#vii. recussive function : function which call or invoke itself
def fact(n):
    if n==1:
        return n
    else:
        return n*fact(n-1) 
    
#vii. lambda or anonyms function : single line function
#tax = lambda x: sum(x)/len(x)
tax = lambda x: x*.18
    
'''
def tax(x):
    t = x*.18
    return t
'''

add(55,6)
add(55,6,55,676,5)
add(55,6,55,676)
add(55,6,55)

mul(111,3,5,67)
mul(111,3,5,67,6,6,3,3,5,76,78,4,7)

f = fact(6)
print(f)


t = tax(556)
print(t)





