
s = input('enter data :')

sc = len(s)  -  len(s.replace(' ',''))
print(sc)



tc = len(s)  -  len(s.replace('\t',''))
print(tc)



nc = len(s)  -  len(s.replace('\n',''))
print(nc)

a ='z'

if a>'a':
    print('z ')
else:
    print('or ')
    




