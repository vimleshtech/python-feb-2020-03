
a=input('enter string ')
b = input('enter string ')

c = a.split(b)
if len(c)>1:
    print(b,' is match at ',len(c[0]))
    




s = a.split(' ')

for word in s:
    if word.istitle():
        print(word)
        
                     
