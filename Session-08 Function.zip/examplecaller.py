import mylib
mylib.add(55,660)
x,y = mylib.getNum()

#or
import mylib as a
a.add(55,6)


#or
from mylib import *
a,b= getNum()

#or
from mylib import add,sub
add(55,6)







