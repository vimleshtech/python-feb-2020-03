#a - append , add new data after existing value 
s=open(r'C:\Users\vkumar15\Desktop\student.txt','a')

#create header in a file
s.write('eid,name,gender,salary\n') # \n new line

#write data in a file
while True:
    ch = input('press y to write data and n for exit ')
    if ch =='y':
        data = input('enter data in id,name,gender,salary format ')
        s.write(data) #add data        
        s.write('\n') #new line 
    elif ch=='n':
        break
    else:
        print('invalid choice ')
        

s.close()
print('file is saved ')





