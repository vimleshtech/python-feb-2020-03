def read_file(file):

    x = open(file,'r')
    rowx = x.readlines()        
    
    for row in rowx:
        print(row)
    x.close()

#call to function 
read_file(r'C:\Users\vkumar15\Desktop\file2.txt')
read_file(r'C:\Users\vkumar15\Desktop\test-file.txt')
