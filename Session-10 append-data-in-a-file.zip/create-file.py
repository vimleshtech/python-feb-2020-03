#create new file 
nf= open(r'C:\Users\vkumar15\Desktop\file2.txt','w')#write mode

for d in range(5):
    data = input('enter data :')
    nf.write(data+'\n')

nf.close()

