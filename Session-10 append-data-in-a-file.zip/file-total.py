s=open(r'C:\Users\vkumar15\Desktop\student.txt','r')

#skip first row
s.readline()


#now read all data lines expcept first row 
data = s.readlines()

t = 0
for row in data:
    #111,name,male,66666
    col = row.split(',') #[111,NAME,MALE,6666]
    if len(col)>2:
        t+= int(col[3])
    else:
        t+= int(col[0])
    
    
print('total sal ',t)


