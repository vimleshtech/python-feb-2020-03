f = open(r'C:\Users\vkumar15\Desktop\test-file.txt')

#print(f.read()) #read all content from file

#print(f.readline()) #read one line

#read all line and convert to list
data = f.readlines()
print(type(data) ) #list

#print(data )  #print all data

#get row count
print('row count ',len(data))

#get col(word) count
wc = 0
for r in data:
    w = r.split(' ')
    wc += len(w)
    print(r)
print('word count ', wc)















