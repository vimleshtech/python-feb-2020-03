class student:
    def studentDetail(s):
        s.rollno=int(input("enter the roll no of student:"))
        s.name=input("enter the name of sudent:")
        s.address=input("enter the addres of the student:")
        s.city=input("enter the city name of student :")
        s.country=input("enter the studnet's country name :")
    def retroll(s):
        return (s.rollno)    

    def show(s):
        print("student's detail")
        print(f"{s.rollno} {s.name} {s.address} {s.city} {s.country}")


#print()
stu=[]
for i in range(0,3):
    s=student()
    s.studentDetail()
    stu.append(s)
#sorting
for i in range(len(stu)):
    for j in range(i+1, len(stu)):
        
        if stu[i].retroll() >stu[j].retroll():
            temp = stu[i]
            stu[i] = stu[j]
            stu[j] = temp

#show or print
for x in stu:
    x.show()




    
