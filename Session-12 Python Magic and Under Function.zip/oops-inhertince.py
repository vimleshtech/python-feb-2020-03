class calc:  #parent class / base class

    def add(self,a,b):
        print(a+b)

    def sub(self,a,b):
        print(a-b)




class dcalc(calc):  #child class/derived class
    def tax(self,amt):
        t = 0
        if amt<10000:
           t = amt*.18
        else:
            t = amt*.12

        print('tax is ',t)



#create an object of child class to access child class method and parent class method
o = dcalc()
o.add(55,6)
o.sub(55,66)
o.tax(6665554)





        




