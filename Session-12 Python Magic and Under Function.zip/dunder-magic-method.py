class employee:

    def __init__(self,name):
        self.name = name
        print('object is created')


    def __repr__(self):
        return f'object name is {self.name}'

    def __add__(self,add):
        return self.name+' '+add.name

    def test(self):
        print('in test ')
        
    @classmethod 
    def add(self,a,b):
        print(a+b)

    def mul(slef,a,b):
        print(a*b)

    @staticmethod     #here @staticmethod is decorator 
    def sub(a,b):
        print(a-b)
        
    def __del__(s):
        print(f'{s.name} is removed, you canot not use further')
        
if __name__ == '__main__':
    print(__name__)
    #create an object
    o = employee('obj1')
    o2 = employee('obj2')

    o.test()
    print(o) #address or method, now __repr__ method will be call
    print(o2)

    print(o+o2)

    #remove the object
    del o
    try:
        o.test()
    except:
        pass
    
    o2.test()
    

    o2.add(11,45)
    
    o2.sub(4455,444)
    employee.sub(55,6)
    employee.add(55,6)
    #employee.mul(55,66) #error
    
    
