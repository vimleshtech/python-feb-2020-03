# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def index(request):
    #return HttpResponse("<h1> This is my first application </h1><p> Name <input type='text' /> </p>")
    return render(request,'login/signup.html')
    
def home(request):
    return HttpResponse('hi, this is home page')


def about(request):
    return HttpResponse('hi, this is about me')
    

def singup(request):
    fn = request.GET["fname"]
    ln= request.GET["lname"]
    email= request.GET["email"]
    pwd= request.GET["pwd"]
    country= request.GET["country"]


    #save data to file
    f = open('user-data.txt','a')
    f.write(fn+","+ln+","+email+","+pwd+","+country+"\n")
    f.close()

    #return HttpResponse("you have entered  "+fn+" "+ln)
    return HttpResponse("<div> <i> Form is submited </i> <p> <a href='http://127.0.0.1:8000/getdata'> Get Data</a> <a href='http://127.0.0.1:8000/' > Back </a> </p></div>")

def getdata(request):
    f = open('user-data.txt','r')
    data = f.readlines()
    res =[]
    for row in data:
        d= {}
        word = row.split(',')
        d['fname']= word[0]
        d['lname']= word[1]
        d['email']= word[2]
        d['pwd']= word[3]
        d['country']= word[4]

        res.append(d)

    return render(request,"login/view-data.html",{"out":res})











