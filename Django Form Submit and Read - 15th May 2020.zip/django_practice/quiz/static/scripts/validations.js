function requierd_field(){
    alert('in requierd function');
}
function email(){
    alert('in requierd function');
}